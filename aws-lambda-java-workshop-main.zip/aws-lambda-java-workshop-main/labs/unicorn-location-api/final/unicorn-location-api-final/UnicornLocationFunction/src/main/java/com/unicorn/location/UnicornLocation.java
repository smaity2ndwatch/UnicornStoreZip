package com.unicorn.location;

public class UnicornLocation {

    private String unicornName;
    private String longitude;
    private String latitude;

    public String getUnicornName() {
        return unicornName;
    }

    public void setUnicornName(String unicornName) {
        this.unicornName = unicornName;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}


