package com.unicorn.broker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnicornStockApplication {

    public static void main(String[] args) {
        SpringApplication.run(UnicornStockApplication.class, args);
    }

}
