package com.unicorn.store.exceptions;

public class ResourceNotFoundException extends RuntimeException{

}
