package com.unicorn.store.exceptions;

public class MissingParameterException extends RuntimeException{

}
