package com.unicorn.store.model;

public enum UnicornEventType {
    UNICORN_CREATED, UNICORN_UPDATED, UNICORN_DELETED
}
